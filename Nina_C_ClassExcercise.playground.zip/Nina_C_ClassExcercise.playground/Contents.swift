import UIKit

enum description1: String {
    case car1 = "Lamborghini"
    case engine = "V12"
    case wheel = "Urus"
    case color = "Yellow"
}

class description2 {
    var wheel: Int = 4
    var engine: Int = 12
    var car1: Int = 1
    func inventory(wheel: Int, engine: Int, car1: Int)-> Int{
        return wheel + engine + car1
    }
}

